# arabic-stop-words
![alt text](fahrasa.png)


أكبر قائمة لمستبعدات الفهرسة العربية على جيت هاب


هذه القائمة حصيلة تجميع مستبعدات الفهرسة من عدة مصادر مختلفة.

Largest list of Arabic stop words on Github. 

## List

Please view list in [here](https://github.com/mohataher/arabic-stop-words/blob/master/list.txt). It contains 750 stop words.

## License

This repsitory is licensed under MIT license.
